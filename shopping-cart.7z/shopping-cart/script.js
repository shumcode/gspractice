// var divArray = document.getElementsByTagName("button");

// console.log(divArray);

// divArray.forEach(function(awesome) {
//   awesome.className = "buttons";
// });
var container = document.getElementById("container");
var button = document.getElementsByTagName("button");

console.log(button);

for (var i = 0; i < 42; i++) {
  container.innerHTML += '<div class="box"><button class="buttons"></button></div>';

}