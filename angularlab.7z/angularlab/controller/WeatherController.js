(function () {
  function WeatherController () {
    var vm = this;

  }


  angular
    .module("app")
    .controller("WeatherController", WeatherController);
})();