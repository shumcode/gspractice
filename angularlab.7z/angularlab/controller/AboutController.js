(function () {
  function AboutController () {
    var vm = this;

  }


  angular
    .module("app")
    .controller("AboutController", AboutController);
})();