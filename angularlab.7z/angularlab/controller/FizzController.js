(function () {
  function FizzController() {
    var vm = this;
    vm.numbers = [];
    vm.runFizz = function () {
      var number = 25;
      for(var i=0; i <= 25; i++) {
        if (i%3===0 && i%5===0) {
          vm.numbers.push("Fizz and Buzz");
        } else if (i%3===0) {
          vm.numbers.push("Fizz");
        } else if (i%5===0) {
          vm.numbers.push("Buzz");
        } else {
          vm.numbers.push(i);
        }
        console.log(vm.numbers);
      }
    }
  }


  angular
    .module("app")
    .controller("FizzController", FizzController);
})();