(function () {
  var fizzComponent = {
    controller: "FizzController",
    template: `
    <input placeholder="Enter a number to fizz">
    <button ng-click="$ctrl.runFizz()">Run Fizz</button>
    <li ng-repeat="number in $ctrl.numbers track by $index">{{ number }}</li>
    `
  };


  angular
    .module("app")
    .component("fizzComponent", fizzComponent);
})();