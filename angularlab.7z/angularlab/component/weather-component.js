(function () {
  var weatherComponent = {
    controller: "WeatherController",
    template: `
    
    `
  };


  angular
    .module("app")
    .component("weatherComponent", weatherComponent);
})();